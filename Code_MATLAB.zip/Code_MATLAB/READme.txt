Code_MATLAB contains the GUI for project. 
Run main.m in MATLAB.